package info.androidhive.keyboard;


import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class KeyboardActivity extends Activity implements OnClickListener {

	String number = "";
	EditText txtNumber;
	EditText txtMessage;
	Button btnSend;
    String letter = "";
	String message = "";



	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_keyboard);

        
		// Init GUI
		txtNumber = (EditText) findViewById(R.id.txtNumber);
		txtMessage = (EditText) findViewById(R.id.txtMesssage);
		btnSend = (Button) findViewById(R.id.btnSMS);
		Button buttonOne = (Button) findViewById(R.id.block1);
		Button buttonTwo = (Button) findViewById(R.id.block2);
		Button buttonThree = (Button) findViewById(R.id.block3);
		Button buttonFour = (Button) findViewById(R.id.block4);
		Button buttonFive = (Button) findViewById(R.id.block5);
		Button buttonSix = (Button) findViewById(R.id.block6);

		
		// Attached Click Listener
		btnSend.setOnClickListener(this);
		txtNumber = (EditText) findViewById(R.id.txtNumber);
		txtMessage = (EditText) findViewById(R.id.txtMesssage);
		buttonOne.setOnClickListener(this);
		buttonTwo.setOnClickListener(this);
		buttonThree.setOnClickListener(this);
		buttonFour.setOnClickListener(this);
		buttonFive.setOnClickListener(this);
		buttonSix.setOnClickListener(this);
		
		
		
		String text = getIntent().getStringExtra("messageBody");
		txtMessage.setText(text);
		
	}
	
//	@Override
	public void onClick(View v) {
							
	

		//Map<String, String> map = new HashMap<String, String>();
		
/*		Timer processTimer = new Timer();
		
		processTimer.schedule(new TimerTask() {
	        public void run() {    
	        	processInput();    
	        }

			private void processInput() {
				// TODO Auto-generated method stub

			}
	    }, 500); // Delay before processing. 

	processTimer.cancel();
	
	processTimer.schedule(new TimerTask() {
	        public void run() {    
	        	processInput();    
	        }

			private void processInput() {
				// TODO Auto-generated method stub

				
			}
	    }, 500); */	
	    
	    	
	switch (v.getId()) {
	
    case R.id.block1:      	
    	//buttonOnePressed = System.nanoTime(); // assign times 
        letter += "A";  
         break;
    case R.id.block2:
    	//buttonTwoPressed = System.nanoTime();
    	letter += "B";
         break;
    case R.id.block3:
        letter += "C"; 
        break;
    case R.id.block4:
        letter += "D";  
        break;
    case R.id.block5:
        letter += "E";
        break;
    case R.id.block6:
        letter += "F";  
        break;
    //    
    default:
    	
    	break;
    }
	//checkIfBothPressed();
	txtMessage.setText(letter);
}
	
	
	
/*	public void checkIfBothPressed() {
    if (Math.abs(buttonOnePressed - buttonTwoPressed) < 100000000) {
    	
    	tts.speak("they pressed it", TextToSpeech.QUEUE_FLUSH, null);
        //Log.i("TimeDiff", "They pressed the buttons within 100000000 nano seconds");
    } else {
        Log.i("TimeDiff", "Late");
    }
} */


/*	public void checkCombo(String mletter) {
	  String generatedLetter;
	  switch(letter) {
	    case "AB":
	     generatedLetter = "Z";// or you can set it to your textview here
	     txtMessage.setText(generatedLetter);
	     letter = ""; // if it goes inside any of your switch case clear your global variable
	     break;
	    case "DEF":
	     generatedLetter = "P";
	     letter = "";
	     break;
	  }

	}*/
	
}

